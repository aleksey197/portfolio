	$(".top_mnu li").sliphover({
		target: "a",
		backgroundColor: "rgba(255,255,255,0.3)"
	});

	https://github.com/wayou/SlipHover